**Project Report**

**Project Title:**

Ludo game using OOP in c++

**Group Members:**

1.  Asad Khan-\[24K-0580\]

2.  Hassan Nasir-\[24K-1031\]

3.  Jiyanshu Raj-\[24K-0987\]

**1)Executive Summary:**

-   **Overview:** This project aimed to develop a simplified version of
    the classic board game Lud*o* using C++ and raylib graphics library,
    following the principles of Object-Oriented Programming (OOP). It
    was developed in Visual Studio Code by focusing on demonstrating the
    application of key OOP concepts such as encapsulation, inheritance,
    polymorphism, and abstraction.

-   **Key Findings:**

    -   Successfully implemented a playable four-player Ludo game.

    -   Developed a clear class structure that reflects real-world game
        components.

    -   Applied OOP concepts effectively to manage complexity and
        scalability.

    -   Demonstrated user interaction through mouse events and
        turn-based gameplay.

**2)Introduction:**

-   **Background:** Object-Oriented Programming structures software
    revolving around real-world entities and objects. Board games like
    Ludo consist of multiple interacting entities (players, tokens,
    dice), making it an ideal project to demonstrate using OOP. By
    creating a digital Ludo game, we showcased core programming logic
    and GUI handling while also reinforcing OOP concepts.

-   **Project Objectives:**

    -   Create an interactive, functional Ludo board game

    -   Apply OOP principles throughout the codebase.

    -   Use simple and beginner-friendly development tools like Visual
        Studio Code and raylib.

    -   Deliver a playable prototype with basic functionality.

**3)Project Description:**

-   **Scope:**

    -   **Include:**

        -   4 Player Ludo game

        -   A rolling dice, movement and turn based logic

        -   Basic GUI using raylib graphics library

        -   Win condition detection

    -   **Excluded:**

        -   Online multiplayer support

        -   Complex animations

-   **Technical Overview:** Object oriented programming on C++.Visual
    Studio Code was the IDE used with Raylib as the graphics library
    while the operating system preferred is Windows

**4)Methodology:**

-   **Approach:** We followed a daily planning approach trying to
    complete are tasks and tackling errors in our code while in the
    University. The project was developed in four main phases: research,
    planning, design, and implementation. Development followed an
    iterative process---features were added incrementally, tested, and
    refined.

-   **Roles and Responsibilities:**

    -   Asad Khan: Sound integration, dice animations, polishing
        features and helping in logic

    ```{=html}
    <!-- -->
    ```
    -   Hassan Nasir: GUI integration using raylib (board display, token
        movement)

    -   Jiyanshu Raj: Core logic & class structure (token classes, dice,
        turns)

**Project Implementation:**

-   **Design and Structure:** Structured using modular OOP design. Major
    Classes included:

    -   Token: Represents each movable piece

    -   Player: Holds token collection and manages player-specific
        actions

    -   Dice: Handles random number generation and display

    -   GameManager: Controls game flow, switching turns, and win
        conditions

-   **Functionalities Developed:**

    -   Dice rolling with randomization

    -   Token selection and movement based on dice value

    -   Turn-based control system

    -   Basic win condition logic (when all tokens reach home)

-   **Challenges Faced:**

    -   Collision Detection: Detecting token overlaps on the board was
        tricky; we resolved this using grid indexing.

    -   GUI Complexity: Managing the game UI with raylib required
        trial-and-error for alignment and scaling.

    -   Turn Logic Bugs: Initial turn-switching logic skipped players;
        fixed through improved state tracking in GameManager.

**6)Results:**

-   **Project Outcomes:**

    -   A working, playable 4-player Ludo game with a simple UI.

    -   Clear demonstration of OOP structure in the form of classes and
        object interactions.

    -   An educational and engaging application suitable for learning
        OOP using C++.

-   **Screenshots and Illustrations:**

> Screenshot with tokens:
>
> ![A screenshot of a game AI-generated content may be
> incorrect.](./image1.png){width="6.268055555555556in"
> height="6.302083333333333in"}
>
> Elimination of tokens:
>
> <https://youtu.be/HSlDOPehwPE>

-   **Testing and Validation:**

    -   Manual play-testing conducted in multiple runs by each member.

    -   Verified dice randomness, token movement legality, and win
        conditions.

    -   Code was reviewed and debugged collaboratively using breakpoints
        and logs.

**7)Conclusion:**

-   **Summary of Findings:** The project demonstrates how Ludo can
    modelled using OOP. By creating real-world classes and simulating
    interactions between them. Core principles such as encapsulation,
    inheritance, and abstraction were used.

-   **Final Remarks:** This project allowed us to gain a valuable
    experience in applying concepts of OOP to create an operational
    project. The project can be enhanced by adding advanced fancy
    animations and integrating AI players to verse.
